javac *.java
java -cp lib/*: InnReservations
