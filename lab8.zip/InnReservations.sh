javac InnReservations.java
java InnReservations
